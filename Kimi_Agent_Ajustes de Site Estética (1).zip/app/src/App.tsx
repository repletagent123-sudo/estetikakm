import { useState, useEffect } from 'react';
import Navbar from './sections/Navbar';
import HeroSection from './sections/HeroSection';
import ParaQuemSection from './sections/ParaQuemSection';
import PlanosSection from './sections/PlanosSection';
import ServicosSection from './sections/ServicosSection';
import AgendamentoSection from './sections/AgendamentoSection';
import Footer from './sections/Footer';
import WhatsAppFloat from './sections/WhatsAppFloat';
import AdminPanel from './sections/AdminPanel';

function App() {
  const [adminOpen, setAdminOpen] = useState(false);
  const [scrollY, setScrollY] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      setScrollY(window.scrollY);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Initialize localStorage data if empty
  useEffect(() => {
    if (!localStorage.getItem('esteticaPro_agendamentos')) {
      localStorage.setItem('esteticaPro_agendamentos', JSON.stringify([]));
    }
    if (!localStorage.getItem('esteticaPro_estoque')) {
      const defaultStock = [
        { id: 1, nome: 'Creme Hidratante Facial', quantidade: 12, status: 'Disponível' },
        { id: 2, nome: 'Máscara de Argila Verde', quantidade: 3, status: 'Alerta de Reposição' },
        { id: 3, nome: 'Luvas de Procedimento', quantidade: 8, status: 'Disponível' },
        { id: 4, nome: 'Agulhas para Botox', quantidade: 25, status: 'Disponível' },
        { id: 5, nome: 'Ácido Hialurônico', quantidade: 2, status: 'Alerta de Reposição' },
      ];
      localStorage.setItem('esteticaPro_estoque', JSON.stringify(defaultStock));
    }
  }, []);

  return (
    <div className="relative min-h-screen bg-white">
      {/* Navigation */}
      <Navbar onAdminClick={() => setAdminOpen(true)} />

      {/* Hero Section */}
      <HeroSection />

      {/* Target Audience */}
      <ParaQuemSection />

      {/* Pricing Plans */}
      <PlanosSection />

      {/* Service Demonstration */}
      <ServicosSection />

      {/* Scheduling Form */}
      <AgendamentoSection />

      {/* Footer */}
      <Footer />

      {/* WhatsApp Floating Button */}
      <WhatsAppFloat />

      {/* Admin Panel Modal */}
      <AdminPanel isOpen={adminOpen} onClose={() => setAdminOpen(false)} />

      {/* Scroll Progress Indicator */}
      <div
        className="fixed top-0 left-0 h-1 bg-[#D8B4FE] z-[55] transition-all duration-100"
        style={{
          width: `${
            scrollY > 0
              ? Math.min(
                  (scrollY / (document.documentElement.scrollHeight - window.innerHeight)) * 100,
                  100
                )
              : 0
          }%`,
        }}
      />
    </div>
  );
}

export default App;
