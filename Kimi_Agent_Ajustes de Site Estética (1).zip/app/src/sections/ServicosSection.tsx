import { useState, useEffect, useRef } from 'react';
import { MessageCircle, TrendingUp } from 'lucide-react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const servicos = [
  {
    id: 1,
    name: 'Limpeza de Pele Profunda',
    description:
      'Remoção de impurezas, cravos e células mortas com produtos dermatologicamente testados. Pele renovada e luminosa.',
    price: 'R$ 120',
    image: '/images/service-facial.jpg',
    tag: 'Mais Popular',
  },
  {
    id: 2,
    name: 'Drenagem Linfática',
    description:
      'Estimulação do sistema linfático para redução de edemas, melhora da circulação e relaxamento profundo.',
    price: 'R$ 150',
    image: '/images/service-drenagem.jpg',
    tag: null,
  },
  {
    id: 3,
    name: 'Massagem Modeladora',
    description:
      'Técnica intensiva para redução de medidas e combate à gordura localizada. Resultados visíveis desde a primeira sessão.',
    price: 'R$ 160',
    image: '/images/service-modeladora.jpg',
    tag: null,
  },
  {
    id: 4,
    name: 'Aplicação de Botox',
    description:
      'Suavização de rugas e linhas de expressão por profissional especializado. Resultado natural e harmonioso.',
    price: 'R$ 350',
    image: '/images/service-botox.jpg',
    tag: 'Premium',
  },
  {
    id: 5,
    name: 'Peeling Químico',
    description:
      'Renovação celular profunda para tratamento de manchas, acne e melasma. Pele mais uniforme e rejuvenescida.',
    price: 'R$ 200',
    image: '/images/service-peeling.jpg',
    tag: null,
  },
  {
    id: 6,
    name: 'Carboxiterapia',
    description:
      'Aplicação de CO2 medicinal para tratamento de celulite, estrias e flacidez. Estimula a produção de colágeno.',
    price: 'R$ 180',
    image: '/images/service-carboxi.jpg',
    tag: null,
  },
  {
    id: 7,
    name: 'Radiofrequência',
    description:
      'Tratamento não invasivo para lifting facial e corporal. Contração do colágeno com resultados imediatos.',
    price: 'R$ 220',
    image: '/images/service-radio.jpg',
    tag: 'Novo',
  },
  {
    id: 8,
    name: 'Microagulhamento',
    description:
      'Indução percutânea de colágeno para tratamento de cicatrizes, poros dilatados e rejuvenescimento facial.',
    price: 'R$ 250',
    image: '/images/service-micro.jpg',
    tag: null,
  },
];

export default function ServicosSection() {
  const [hoveredId, setHoveredId] = useState<number | null>(null);
  const [previewImage, setPreviewImage] = useState(servicos[0].image);
  const sectionRef = useRef<HTMLElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);

  // Update preview image on hover
  useEffect(() => {
    if (hoveredId !== null) {
      const s = servicos.find((s) => s.id === hoveredId);
      if (s) setPreviewImage(s.image);
    }
  }, [hoveredId]);

  useEffect(() => {
    const section = sectionRef.current;
    const cards = cardsRef.current;
    if (!section || !cards) return;

    const triggers: ScrollTrigger[] = [];

    // Header animation
    const headerTl = gsap.timeline({
      scrollTrigger: {
        trigger: section,
        start: 'top 80%',
        toggleActions: 'play none none reverse',
      },
    });
    headerTl.fromTo(
      section.querySelector('.servicos-header'),
      { opacity: 0, y: 40 },
      { opacity: 1, y: 0, duration: 0.8, ease: 'power3.out' }
    );
    if (headerTl.scrollTrigger) triggers.push(headerTl.scrollTrigger);

    // Cards stagger
    const cardEls = cards.querySelectorAll('.service-card');
    const cardsTl = gsap.timeline({
      scrollTrigger: {
        trigger: cards,
        start: 'top 80%',
        toggleActions: 'play none none reverse',
      },
    });
    cardsTl.fromTo(
      cardEls,
      { opacity: 0, y: 40, scale: 0.97 },
      {
        opacity: 1,
        y: 0,
        scale: 1,
        duration: 0.6,
        stagger: 0.08,
        ease: 'power3.out',
      }
    );
    if (cardsTl.scrollTrigger) triggers.push(cardsTl.scrollTrigger);

    return () => {
      triggers.forEach((t) => t.kill());
    };
  }, []);

  const agendar = (servico: string, preco: string) => {
    const msg = encodeURIComponent(
      `Olá! Quero agendar o serviço de *${servico}* (${preco})`
    );
    window.open(`https://wa.me/5511953429077?text=${msg}`, '_blank');
  };

  return (
    <section
      id="servicos"
      ref={sectionRef}
      className="relative py-24 sm:py-32 bg-white overflow-hidden"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="servicos-header text-center mb-16">
          <span className="inline-block px-4 py-1.5 bg-[#240046] text-white text-xs font-bold uppercase tracking-widest mb-4">
            Demonstração
          </span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-light text-[#240046] tracking-tight uppercase">
            Veja Como Fica Seu{' '}
            <span className="font-medium">Catálogo Digital</span>
          </h2>
          <p className="mt-4 text-lg text-[#240046]/60 max-w-2xl mx-auto">
            Exemplo de catálogo de serviços com agendamento direto pelo WhatsApp.
            Seus clientes assim.
          </p>
        </div>

        {/* Split Layout: Service List + Preview */}
        <div className="grid lg:grid-cols-2 gap-8 lg:gap-12">
          {/* Left: Service List */}
          <div ref={cardsRef} className="space-y-4">
            {servicos.map((s) => (
              <div
                key={s.id}
                className={`service-card group relative bg-[#F5F5F5] border-2 p-4 sm:p-5 cursor-pointer transition-all duration-300 hover:bg-white hover:shadow-brutalist hover:-translate-x-px hover:-translate-y-px ${
                  hoveredId === s.id
                    ? 'border-[#240046] bg-white shadow-brutalist'
                    : 'border-transparent'
                }`}
                onMouseEnter={() => setHoveredId(s.id)}
                onMouseLeave={() => setHoveredId(null)}
              >
                <div className="flex items-center justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="text-base sm:text-lg font-semibold text-[#240046] truncate">
                        {s.name}
                      </h3>
                      {s.tag && (
                        <span className="flex-shrink-0 px-2 py-0.5 bg-[#240046] text-white text-[10px] font-bold uppercase tracking-wider">
                          {s.tag}
                      </span>
                      )}
                    </div>
                    <p className="text-xs sm:text-sm text-[#240046]/50 line-clamp-1">
                      {s.description}
                    </p>
                  </div>
                  <div className="flex items-center gap-3 flex-shrink-0">
                    <span className="text-xl sm:text-2xl font-display italic text-[#240046]">
                      {s.price}
                    </span>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        agendar(s.name, s.price);
                      }}
                      className="px-4 py-2 bg-[#240046] text-white text-xs font-bold uppercase tracking-wider hover:bg-[#31154F] transition-colors flex items-center gap-1.5"
                    >
                      <MessageCircle className="w-3.5 h-3.5" />
                      <span className="hidden sm:inline">Agendar</span>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Right: Preview Image */}
          <div className="hidden lg:block relative">
            <div className="sticky top-32">
              <div className="relative aspect-[4/3] overflow-hidden border-2 border-[#240046]/10">
                <img
                  src={previewImage}
                  alt="Preview"
                  className="w-full h-full object-cover transition-all duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#240046]/40 to-transparent" />
                
                {/* Floating stats */}
                <div className="absolute bottom-4 left-4 right-4">
                  <div className="bg-white/95 backdrop-blur-sm p-4 border border-[#240046]/10">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-emerald-100 flex items-center justify-center flex-shrink-0">
                        <TrendingUp className="w-5 h-5 text-emerald-600" />
                      </div>
                      <div>
                        <div className="text-sm font-bold text-[#240046]">
                          +47% de conversão
                        </div>
                        <div className="text-xs text-[#240046]/50">
                          Média dos nossos clientes
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Note */}
              <p className="mt-4 text-xs text-[#240046]/40 text-center uppercase tracking-wider">
                Passe o mouse nos serviços para visualizar
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
