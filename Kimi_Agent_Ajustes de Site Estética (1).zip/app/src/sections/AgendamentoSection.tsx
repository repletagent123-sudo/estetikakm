import { useState, useEffect, useRef } from 'react';
import { MessageCircle, Calendar, Clock, AlertCircle } from 'lucide-react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const servicosOptions = [
  'Limpeza de Pele Profunda — R$ 120,00',
  'Drenagem Linfática — R$ 150,00',
  'Massagem Modeladora — R$ 160,00',
  'Aplicação de Botox — R$ 350,00',
  'Peeling Químico — R$ 200,00',
  'Carboxiterapia — R$ 180,00',
  'Radiofrequência — R$ 220,00',
  'Microagulhamento — R$ 250,00',
];

export default function AgendamentoSection() {
  const [nome, setNome] = useState('');
  const [telefone, setTelefone] = useState('');
  const [procedimento, setProcedimento] = useState('');
  const [data, setData] = useState('');
  const [hora, setHora] = useState('');
  const [dataErro, setDataErro] = useState('');
  const [toast, setToast] = useState<{ msg: string; type: string } | null>(null);
  const sectionRef = useRef<HTMLElement>(null);
  const formRef = useRef<HTMLDivElement>(null);

  const horarios: string[] = [];
  for (let h = 8; h <= 18; h++) {
    const horaStr = h.toString().padStart(2, '0');
    horarios.push(`${horaStr}:00`);
    if (h !== 18) horarios.push(`${horaStr}:30`);
  }

  useEffect(() => {
    const section = sectionRef.current;
    const form = formRef.current;
    if (!section || !form) return;

    const triggers: ScrollTrigger[] = [];

    const tl = gsap.timeline({
      scrollTrigger: {
        trigger: section,
        start: 'top 80%',
        toggleActions: 'play none none reverse',
      },
    });

    tl.fromTo(
      section.querySelector('.agendamento-header'),
      { opacity: 0, y: 40 },
      { opacity: 1, y: 0, duration: 0.8, ease: 'power3.out' }
    ).fromTo(
      form,
      { opacity: 0, y: 50, scale: 0.97 },
      { opacity: 1, y: 0, scale: 1, duration: 0.8, ease: 'power3.out' },
      '-=0.4'
    );

    if (tl.scrollTrigger) triggers.push(tl.scrollTrigger);

    return () => {
      triggers.forEach((t) => t.kill());
    };
  }, []);

  useEffect(() => {
    if (toast) {
      const timer = setTimeout(() => setToast(null), 3000);
      return () => clearTimeout(timer);
    }
  }, [toast]);

  const formatDateISO = (date: Date) => date.toISOString().split('T')[0];

  const handleDataChange = (value: string) => {
    setData(value);
    if (!value) {
      setDataErro('');
      return;
    }
    const dataObj = new Date(value + 'T12:00:00');
    if (dataObj.getDay() === 0) {
      setDataErro('Domingos não são permitidos. Escolha Seg-Sáb.');
      setData('');
    } else {
      setDataErro('');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nome || !telefone || !procedimento || !data || !hora) {
      setToast({ msg: 'Preencha todos os campos!', type: 'error' });
      return;
    }

    const dataObj = new Date(data + 'T12:00:00');
    if (dataObj.getDay() === 0) {
      setToast({ msg: 'Não atendemos aos domingos!', type: 'error' });
      return;
    }

    // Save to localStorage
    const agendamentos = JSON.parse(
      localStorage.getItem('esteticaPro_agendamentos') || '[]'
    );
    agendamentos.unshift({
      id: Date.now(),
      nome,
      telefone,
      procedimento,
      data,
      hora,
      criadoEm: new Date().toLocaleString('pt-BR'),
    });
    localStorage.setItem(
      'esteticaPro_agendamentos',
      JSON.stringify(agendamentos)
    );

    // Format date
    const [ano, mes, dia] = data.split('-');
    const dataBR = `${dia}/${mes}/${ano}`;

    const msg = encodeURIComponent(
      `*🌸 Novo Agendamento - Estética Pro*\n\n` +
        `*Nome:* ${nome}\n` +
        `*Telefone:* ${telefone}\n` +
        `*Serviço:* ${procedimento}\n` +
        `*Data:* ${dataBR}\n` +
        `*Horário:* ${hora}\n\n` +
        `Aguardo confirmação! ✅`
    );

    window.open(`https://wa.me/5511953429077?text=${msg}`, '_blank');
    setToast({ msg: 'Agendamento enviado via WhatsApp!', type: 'success' });

    // Reset form
    setNome('');
    setTelefone('');
    setProcedimento('');
    setData('');
    setHora('');
  };

  // Set min date to tomorrow
  const hoje = new Date();
  const amanha = new Date(hoje);
  amanha.setDate(amanha.getDate() + 1);
  const minDate = formatDateISO(amanha);
  const maxDate = formatDateISO(new Date(hoje.getTime() + 60 * 24 * 60 * 60 * 1000));

  return (
    <section
      id="agendamento"
      ref={sectionRef}
      className="relative py-24 sm:py-32 bg-[#240046] overflow-hidden"
    >
      {/* Background decoration */}
      <div className="absolute inset-0 opacity-10">
        <div
          className="absolute top-20 right-20 w-96 h-96 bg-purple-400 rounded-full blur-[150px]"
        />
        <div
          className="absolute bottom-20 left-20 w-80 h-80 bg-pink-400 rounded-full blur-[120px]"
        />
      </div>

      <div className="relative max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="agendamento-header text-center mb-12">
          <span className="inline-block px-4 py-1.5 bg-white/10 backdrop-blur-sm border border-white/20 text-white text-xs font-bold uppercase tracking-widest mb-4">
            Agendamento
          </span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-light text-white tracking-tight uppercase">
            Agende Seu <span className="font-medium">Horário</span>
          </h2>
          <p className="mt-4 text-lg text-white/60">
            Preencha os dados abaixo e envie diretamente pelo WhatsApp
          </p>
        </div>

        {/* Form */}
        <div
          ref={formRef}
          className="bg-white p-8 sm:p-10 border-2 border-white/10 shadow-2xl"
        >
          <form onSubmit={handleSubmit}>
            <div className="grid sm:grid-cols-2 gap-6 mb-6">
              {/* Nome */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#240046]/70 mb-2">
                  Nome Completo
                </label>
                <input
                  type="text"
                  value={nome}
                  onChange={(e) => setNome(e.target.value)}
                  required
                  className="w-full px-4 py-3 border-2 border-[#240046]/10 text-[#240046] placeholder:text-[#240046]/30 focus:border-[#240046] focus:outline-none transition-colors"
                  placeholder="Seu nome"
                />
              </div>

              {/* Telefone */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-[#240046]/70 mb-2">
                  Telefone
                </label>
                <input
                  type="tel"
                  value={telefone}
                  onChange={(e) => setTelefone(e.target.value)}
                  required
                  className="w-full px-4 py-3 border-2 border-[#240046]/10 text-[#240046] placeholder:text-[#240046]/30 focus:border-[#240046] focus:outline-none transition-colors"
                  placeholder="(11) 99999-9999"
                />
              </div>
            </div>

            {/* Procedimento */}
            <div className="mb-6">
              <label className="block text-xs font-bold uppercase tracking-wider text-[#240046]/70 mb-2">
                Procedimento Desejado
              </label>
              <div className="relative">
                <select
                  value={procedimento}
                  onChange={(e) => setProcedimento(e.target.value)}
                  required
                  className="w-full px-4 py-3 border-2 border-[#240046]/10 text-[#240046] focus:border-[#240046] focus:outline-none transition-colors appearance-none bg-white"
                >
                  <option value="">Selecione um serviço</option>
                  {servicosOptions.map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </select>
                <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none">
                  <svg
                    className="w-4 h-4 text-[#240046]/50"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M19 9l-7 7-7-7"
                    />
                  </svg>
                </div>
              </div>
            </div>

            <div className="grid sm:grid-cols-2 gap-6 mb-8">
              {/* Data */}
              <div>
                <label className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#240046]/70 mb-2">
                  <Calendar className="w-4 h-4" />
                  Data
                </label>
                <input
                  type="date"
                  value={data}
                  onChange={(e) => handleDataChange(e.target.value)}
                  min={minDate}
                  max={maxDate}
                  required
                  className="w-full px-4 py-3 border-2 border-[#240046]/10 text-[#240046] focus:border-[#240046] focus:outline-none transition-colors"
                />
                {dataErro && (
                  <p className="flex items-center gap-1 text-red-500 text-xs mt-2">
                    <AlertCircle className="w-3 h-3" />
                    {dataErro}
                  </p>
                )}
              </div>

              {/* Hora */}
              <div>
                <label className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#240046]/70 mb-2">
                  <Clock className="w-4 h-4" />
                  Horário
                </label>
                <div className="relative">
                  <select
                    value={hora}
                    onChange={(e) => setHora(e.target.value)}
                    required
                    className="w-full px-4 py-3 border-2 border-[#240046]/10 text-[#240046] focus:border-[#240046] focus:outline-none transition-colors appearance-none bg-white"
                  >
                    <option value="">Selecione</option>
                    {horarios.map((h) => (
                      <option key={h} value={h}>
                        {h}
                      </option>
                    ))}
                  </select>
                  <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none">
                    <svg
                      className="w-4 h-4 text-[#240046]/50"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M19 9l-7 7-7-7"
                      />
                    </svg>
                  </div>
                </div>

              </div>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              className="w-full py-4 bg-[#240046] text-white font-bold uppercase tracking-wider text-sm hover:bg-[#31154F] hover:shadow-brutalist-white hover:-translate-x-px hover:-translate-y-px transition-all flex items-center justify-center gap-2"
            >
              <MessageCircle className="w-5 h-5" />
              Finalizar e Agendar via WhatsApp
            </button>
          </form>
        </div>
      </div>

      {/* Toast */}
      {toast && (
        <div
          className={`fixed bottom-24 right-6 z-50 px-6 py-4 shadow-2xl border-2 animate-fade-in ${
            toast.type === 'error'
              ? 'bg-red-50 border-red-200 text-red-700'
              : 'bg-emerald-50 border-emerald-200 text-emerald-700'
          }`}
        >
          <p className="text-sm font-semibold">{toast.msg}</p>
        </div>
      )}
    </section>
  );
}
