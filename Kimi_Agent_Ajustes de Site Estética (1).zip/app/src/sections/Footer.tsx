import { Mail } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="relative bg-[#240046] pt-20 pb-8 overflow-hidden">
      {/* Large watermark text */}
      <div className="absolute inset-0 flex items-center justify-center overflow-hidden pointer-events-none select-none">
        <span className="text-[20vw] font-bold text-white/[0.03] uppercase tracking-tighter whitespace-nowrap">
          AURASITES
        </span>
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main footer content */}
        <div className="text-center mb-16">
          <div className="flex items-center justify-center gap-3 mb-6">
            <div className="w-12 h-12 bg-white/10 backdrop-blur-sm border border-white/20 flex items-center justify-center">
              <svg
                className="w-7 h-7 text-white"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={1.5}
                  d="M13 10V3L4 14h7v7l9-11h-7z"
                />
              </svg>
            </div>
            <span className="text-3xl font-bold text-white tracking-tight">
              AURA<span className="text-[#D8B4FE]">SITES</span>
            </span>
          </div>
          <p className="text-lg text-white/70 mb-2">
            Sites Profissionais para Esteticistas e Clínicas de Estética
          </p>
          <p className="text-sm text-white/50 flex items-center justify-center gap-2">
            <Mail className="w-4 h-4" />
            <a
              href="mailto:flaviojorrge@gmail.com"
              className="text-[#D8B4FE] hover:underline transition-colors"
            >
              flaviojorrge@gmail.com
            </a>
          </p>
        </div>

        {/* Links grid */}
        <div className="grid sm:grid-cols-3 gap-8 mb-16 max-w-2xl mx-auto text-center">
          <div>
            <h4 className="text-xs font-bold uppercase tracking-widest text-white/40 mb-3">
              Serviços
            </h4>
            <ul className="space-y-2">
              <li>
                <span className="text-sm text-white/60 hover:text-white transition-colors cursor-pointer">
                  Criação de Sites
                </span>
              </li>
              <li>
                <span className="text-sm text-white/60 hover:text-white transition-colors cursor-pointer">
                  Gestão Mensal
                </span>
              </li>
              <li>
                <span className="text-sm text-white/60 hover:text-white transition-colors cursor-pointer">
                  Combo Completo
                </span>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="text-xs font-bold uppercase tracking-widest text-white/40 mb-3">
              Recursos
            </h4>
            <ul className="space-y-2">
              <li>
                <span className="text-sm text-white/60 hover:text-white transition-colors cursor-pointer">
                  Agendamento WhatsApp
                </span>
              </li>
              <li>
                <span className="text-sm text-white/60 hover:text-white transition-colors cursor-pointer">
                  Catálogo Digital
                </span>
              </li>
              <li>
                <span className="text-sm text-white/60 hover:text-white transition-colors cursor-pointer">
                  Painel Administrativo
                </span>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="text-xs font-bold uppercase tracking-widest text-white/40 mb-3">
              Suporte
            </h4>
            <ul className="space-y-2">
              <li>
                <span className="text-sm text-white/60 hover:text-white transition-colors cursor-pointer">
                  WhatsApp
                </span>
              </li>
              <li>
                <span className="text-sm text-white/60 hover:text-white transition-colors cursor-pointer">
                  Email
                </span>
              </li>
              <li>
                <span className="text-sm text-white/60 hover:text-white transition-colors cursor-pointer">
                  FAQ
                </span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="border-t border-white/10 pt-6">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <p className="text-xs text-white/40">
              &copy; 2026 AuraSites. Todos os direitos reservados.
            </p>
            <div className="flex items-center gap-4">
              <span className="text-xs text-white/40 hover:text-white/60 transition-colors cursor-pointer">
                Termos de Uso
              </span>
              <span className="text-xs text-white/40 hover:text-white/60 transition-colors cursor-pointer">
                Política de Privacidade
              </span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
