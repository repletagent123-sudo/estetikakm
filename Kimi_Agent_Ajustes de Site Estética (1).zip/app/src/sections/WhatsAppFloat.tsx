import { MessageCircle } from 'lucide-react';

export default function WhatsAppFloat() {
  const openWhatsApp = () => {
    const msg = encodeURIComponent(
      'Olá! Quero saber mais sobre o site profissional para minha clínica de estética'
    );
    window.open(`https://wa.me/5511953429077?text=${msg}`, '_blank');
  };

  return (
    <button
      onClick={openWhatsApp}
      className="fixed bottom-6 right-6 z-50 bg-emerald-500 hover:bg-emerald-600 text-white p-4 rounded-full shadow-2xl hover:scale-110 transition-all duration-300 animate-pulse-glow"
      aria-label="WhatsApp"
    >
      <MessageCircle className="w-7 h-7" />
    </button>
  );
}
