import { useState, useEffect } from 'react';
import { Menu, X, Shield } from 'lucide-react';

interface NavbarProps {
  onAdminClick: () => void;
}

export default function Navbar({ onAdminClick }: NavbarProps) {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollTo = (id: string) => {
    const el = document.querySelector(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
      setMobileOpen(false);
    }
  };

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? 'bg-[#240046]/95 backdrop-blur-xl shadow-lg'
          : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <button
            onClick={() => scrollTo('#hero')}
            className="flex items-center gap-3 group"
          >
            <div className="w-10 h-10 bg-white/10 backdrop-blur-sm border border-white/20 rounded flex items-center justify-center group-hover:bg-white/20 transition-all">
              <svg
                className="w-6 h-6 text-white"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={1.5}
                  d="M13 10V3L4 14h7v7l9-11h-7z"
                />
              </svg>
            </div>
            <span className="text-xl font-bold text-white tracking-tight">
              AURA<span className="text-[#D8B4FE]">SITES</span>
            </span>
          </button>

          {/* Desktop Links */}
          <div className="hidden md:flex items-center gap-8">
            <button
              onClick={() => scrollTo('#planos')}
              className="text-sm font-medium text-white/70 hover:text-white transition-colors uppercase tracking-wider"
            >
              Planos
            </button>
            <button
              onClick={() => scrollTo('#servicos')}
              className="text-sm font-medium text-white/70 hover:text-white transition-colors uppercase tracking-wider"
            >
              Demonstração
            </button>
            <button
              onClick={() => scrollTo('#agendamento')}
              className="text-sm font-medium text-white/70 hover:text-white transition-colors uppercase tracking-wider"
            >
              Agendar
            </button>
            <button
              onClick={onAdminClick}
              className="text-sm font-medium text-white/50 hover:text-white transition-colors flex items-center gap-2"
            >
              <Shield className="w-4 h-4" />
              Painel
            </button>
            <button
              onClick={() => scrollTo('#planos')}
              className="px-6 py-2.5 bg-white text-[#240046] text-sm font-bold uppercase tracking-wider hover:shadow-brutalist-hover hover:-translate-x-px hover:-translate-y-px transition-all"
            >
              Começar Agora
            </button>
          </div>

          {/* Mobile Toggle */}
          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="md:hidden p-2 text-white"
          >
            {mobileOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <div
        className={`md:hidden bg-[#240046]/98 backdrop-blur-xl transition-all duration-300 overflow-hidden ${
          mobileOpen ? 'max-h-96 border-t border-white/10' : 'max-h-0'
        }`}
      >
        <div className="px-4 py-4 space-y-3">
          <button
            onClick={() => scrollTo('#planos')}
            className="block w-full text-left px-4 py-3 text-white/80 hover:text-white hover:bg-white/5 rounded transition"
          >
            Planos
          </button>
          <button
            onClick={() => scrollTo('#servicos')}
            className="block w-full text-left px-4 py-3 text-white/80 hover:text-white hover:bg-white/5 rounded transition"
          >
            Demonstração
          </button>
          <button
            onClick={() => scrollTo('#agendamento')}
            className="block w-full text-left px-4 py-3 text-white/80 hover:text-white hover:bg-white/5 rounded transition"
          >
            Agendar
          </button>
          <button
            onClick={() => {
              onAdminClick();
              setMobileOpen(false);
            }}
            className="block w-full text-left px-4 py-3 text-white/50 hover:text-white hover:bg-white/5 rounded transition"
          >
            Painel Interno
          </button>
        </div>
      </div>
    </nav>
  );
}
