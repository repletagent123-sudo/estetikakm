import { useState, useEffect } from 'react';
import {
  X,
  Trash2,
  CalendarDays,
  Package,
  Plus,
  Minus,
  AlertTriangle,
  CheckCircle2,
  Search,
} from 'lucide-react';

interface Agendamento {
  id: number;
  nome: string;
  telefone: string;
  procedimento: string;
  data: string;
  hora: string;
  criadoEm: string;
}

interface Produto {
  id: number;
  nome: string;
  quantidade: number;
  status: string;
}

const defaultStock: Produto[] = [
  { id: 1, nome: 'Creme Hidratante Facial', quantidade: 12, status: 'Disponível' },
  { id: 2, nome: 'Máscara de Argila Verde', quantidade: 3, status: 'Alerta de Reposição' },
  { id: 3, nome: 'Luvas de Procedimento', quantidade: 8, status: 'Disponível' },
  { id: 4, nome: 'Agulhas para Botox', quantidade: 25, status: 'Disponível' },
  { id: 5, nome: 'Ácido Hialurônico', quantidade: 2, status: 'Alerta de Reposição' },
];

interface AdminPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function AdminPanel({ isOpen, onClose }: AdminPanelProps) {
  const [activeTab, setActiveTab] = useState<'agendamentos' | 'estoque'>('agendamentos');
  const [agendamentos, setAgendamentos] = useState<Agendamento[]>([]);
  const [estoque, setEstoque] = useState<Produto[]>([]);
  const [showAddProduct, setShowAddProduct] = useState(false);
  const [produtoNome, setProdutoNome] = useState('');
  const [produtoQtd, setProdutoQtd] = useState('');
  const [produtoStatus, setProdutoStatus] = useState('Disponível');
  const [searchTerm, setSearchTerm] = useState('');
  const [toast, setToast] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      loadData();
    }
  }, [isOpen]);

  useEffect(() => {
    if (toast) {
      const timer = setTimeout(() => setToast(null), 2500);
      return () => clearTimeout(timer);
    }
  }, [toast]);

  const loadData = () => {
    const ag = JSON.parse(localStorage.getItem('esteticaPro_agendamentos') || '[]');
    setAgendamentos(ag);

    const est = JSON.parse(localStorage.getItem('esteticaPro_estoque') || '[]');
    if (est.length === 0) {
      localStorage.setItem('esteticaPro_estoque', JSON.stringify(defaultStock));
      setEstoque(defaultStock);
    } else {
      setEstoque(est);
    }
  };

  const formatarDataBR = (dataISO: string) => {
    const [ano, mes, dia] = dataISO.split('-');
    return `${dia}/${mes}/${ano}`;
  };

  const deleteAgendamento = (id: number) => {
    const updated = agendamentos.filter((a) => a.id !== id);
    setAgendamentos(updated);
    localStorage.setItem('esteticaPro_agendamentos', JSON.stringify(updated));
    setToast('Agendamento removido');
  };

  const clearAllAgendamentos = () => {
    if (confirm('Tem certeza que deseja apagar TODOS os agendamentos?')) {
      setAgendamentos([]);
      localStorage.removeItem('esteticaPro_agendamentos');
      setToast('Todos os agendamentos removidos');
    }
  };

  const addProduct = () => {
    const nome = produtoNome.trim();
    const qtd = parseInt(produtoQtd);
    if (!nome || isNaN(qtd) || qtd < 0) {
      setToast('Preencha todos os campos corretamente!');
      return;
    }
    const updated = [
      ...estoque,
      { id: Date.now(), nome, quantidade: qtd, status: produtoStatus },
    ];
    setEstoque(updated);
    localStorage.setItem('esteticaPro_estoque', JSON.stringify(updated));
    setProdutoNome('');
    setProdutoQtd('');
    setProdutoStatus('Disponível');
    setShowAddProduct(false);
    setToast('Produto adicionado!');
  };

  const editStock = (id: number, delta: number) => {
    const updated = estoque.map((p) => {
      if (p.id !== id) return p;
      const novaQtd = Math.max(0, p.quantidade + delta);
      return {
        ...p,
        quantidade: novaQtd,
        status: novaQtd <= 5 ? 'Alerta de Reposição' : 'Disponível',
      };
    });
    setEstoque(updated);
    localStorage.setItem('esteticaPro_estoque', JSON.stringify(updated));
  };

  const deleteProduct = (id: number) => {
    if (!confirm('Remover este produto do estoque?')) return;
    const updated = estoque.filter((p) => p.id !== id);
    setEstoque(updated);
    localStorage.setItem('esteticaPro_estoque', JSON.stringify(updated));
    setToast('Produto removido');
  };

  const filteredAgendamentos = agendamentos.filter(
    (a) =>
      a.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
      a.procedimento.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredEstoque = estoque.filter((p) =>
    p.nome.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[60] bg-black/50 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-4xl max-h-[85vh] overflow-hidden shadow-2xl border-2 border-[#240046]/10 flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-[#240046]/10 bg-[#240046]">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-white/20 flex items-center justify-center">
              {activeTab === 'agendamentos' ? (
                <CalendarDays className="w-4 h-4 text-white" />
              ) : (
                <Package className="w-4 h-4 text-white" />
              )}
            </div>
            <h2 className="text-lg font-semibold text-white">
              Painel {activeTab === 'agendamentos' ? 'de Agendamentos' : 'de Estoque'}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors"
          >
            <X className="w-5 h-5 text-white" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-[#240046]/10">
          <button
            onClick={() => setActiveTab('agendamentos')}
            className={`flex-1 px-4 py-3 text-sm font-semibold transition-colors flex items-center justify-center gap-2 ${
              activeTab === 'agendamentos'
                ? 'text-[#240046] border-b-2 border-[#240046] bg-[#240046]/5'
                : 'text-[#240046]/50 hover:text-[#240046]/70'
            }`}
          >
            <CalendarDays className="w-4 h-4" />
            Agendamentos
            <span className="px-2 py-0.5 bg-[#240046]/10 text-[#240046] text-xs rounded-full">
              {agendamentos.length}
            </span>
          </button>
          <button
            onClick={() => setActiveTab('estoque')}
            className={`flex-1 px-4 py-3 text-sm font-semibold transition-colors flex items-center justify-center gap-2 ${
              activeTab === 'estoque'
                ? 'text-[#240046] border-b-2 border-[#240046] bg-[#240046]/5'
                : 'text-[#240046]/50 hover:text-[#240046]/70'
            }`}
          >
            <Package className="w-4 h-4" />
            Estoque
            <span className="px-2 py-0.5 bg-[#240046]/10 text-[#240046] text-xs rounded-full">
              {estoque.length}
            </span>
          </button>
        </div>

        {/* Search Bar */}
        <div className="p-4 border-b border-[#240046]/5">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#240046]/40" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Buscar..."
              className="w-full pl-10 pr-4 py-2 border border-[#240046]/10 text-[#240046] placeholder:text-[#240046]/30 focus:border-[#240046] focus:outline-none text-sm"
            />
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-auto p-6">
          {activeTab === 'agendamentos' ? (
            <div>
              {filteredAgendamentos.length === 0 ? (
                <div className="text-center py-12 text-[#240046]/40">
                  <CalendarDays className="w-12 h-12 mx-auto mb-3 opacity-50" />
                  <p className="text-sm">
                    {searchTerm ? 'Nenhum resultado encontrado' : 'Nenhum agendamento registrado'}
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {filteredAgendamentos.map((a) => (
                    <div
                      key={a.id}
                      className="flex items-center justify-between p-4 bg-[#F5F5F5] border border-[#240046]/5 hover:border-[#240046]/20 transition-colors"
                    >
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-3 mb-1">
                          <span className="text-sm font-semibold text-[#240046]">
                            {formatarDataBR(a.data)}
                          </span>
                          <span className="text-xs text-[#240046]/50">{a.hora}</span>
                        </div>
                        <p className="text-sm text-[#240046]/80 truncate">{a.nome}</p>
                        <p className="text-xs text-[#240046]/50">{a.procedimento}</p>
                      </div>
                      <button
                        onClick={() => deleteAgendamento(a.id)}
                        className="ml-4 p-2 text-red-400 hover:text-red-600 hover:bg-red-50 transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              )}

              {agendamentos.length > 0 && (
                <button
                  onClick={clearAllAgendamentos}
                  className="mt-4 w-full py-3 border-2 border-red-200 text-red-500 text-sm font-semibold hover:bg-red-50 transition-colors"
                >
                  Limpar Todos os Agendamentos
                </button>
              )}
            </div>
          ) : (
            <div>
              {/* Add Product Button */}
              <button
                onClick={() => setShowAddProduct(!showAddProduct)}
                className="mb-4 px-4 py-2 bg-[#240046] text-white text-sm font-semibold hover:bg-[#31154F] transition-colors flex items-center gap-2"
              >
                <Plus className="w-4 h-4" />
                Adicionar Produto
              </button>

              {/* Add Product Form */}
              {showAddProduct && (
                <div className="mb-6 p-4 bg-[#F5F5F5] border border-[#240046]/10">
                  <div className="grid sm:grid-cols-3 gap-3">
                    <input
                      type="text"
                      value={produtoNome}
                      onChange={(e) => setProdutoNome(e.target.value)}
                      placeholder="Nome do produto"
                      className="px-3 py-2 border border-[#240046]/10 text-[#240046] text-sm focus:border-[#240046] focus:outline-none"
                    />
                    <input
                      type="number"
                      value={produtoQtd}
                      onChange={(e) => setProdutoQtd(e.target.value)}
                      placeholder="Quantidade"
                      min="0"
                      className="px-3 py-2 border border-[#240046]/10 text-[#240046] text-sm focus:border-[#240046] focus:outline-none"
                    />
                    <select
                      value={produtoStatus}
                      onChange={(e) => setProdutoStatus(e.target.value)}
                      className="px-3 py-2 border border-[#240046]/10 text-[#240046] text-sm focus:border-[#240046] focus:outline-none bg-white"
                    >
                      <option value="Disponível">Disponível</option>
                      <option value="Alerta de Reposição">Alerta de Reposição</option>
                    </select>
                  </div>
                  <button
                    onClick={addProduct}
                    className="mt-3 px-4 py-2 bg-emerald-600 text-white text-sm font-semibold hover:bg-emerald-700 transition-colors"
                  >
                    Salvar Produto
                  </button>
                </div>
              )}

              {/* Products List */}
              {filteredEstoque.length === 0 ? (
                <div className="text-center py-12 text-[#240046]/40">
                  <Package className="w-12 h-12 mx-auto mb-3 opacity-50" />
                  <p className="text-sm">
                    {searchTerm ? 'Nenhum resultado encontrado' : 'Nenhum produto cadastrado'}
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {filteredEstoque.map((p) => (
                    <div
                      key={p.id}
                      className="flex items-center justify-between p-4 bg-[#F5F5F5] border border-[#240046]/5 hover:border-[#240046]/20 transition-colors"
                    >
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-semibold text-[#240046]">{p.nome}</p>
                        <div className="flex items-center gap-2 mt-1">
                          <span
                            className={`text-xs font-bold ${
                              p.quantidade <= 5 ? 'text-red-500' : 'text-emerald-600'
                            }`}
                          >
                            {p.quantidade} un
                          </span>
                          <span
                            className={`px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider ${
                              p.status === 'Disponível'
                                ? 'bg-emerald-100 text-emerald-700'
                                : 'bg-amber-100 text-amber-700'
                            }`}
                          >
                            {p.status === 'Alerta de Reposição' ? (
                              <span className="flex items-center gap-1">
                                <AlertTriangle className="w-3 h-3" />
                                Alerta
                              </span>
                            ) : (
                              <span className="flex items-center gap-1">
                                <CheckCircle2 className="w-3 h-3" />
                                OK
                              </span>
                            )}
                          </span>
                        </div>
                      </div>
                      <div className="flex items-center gap-1 ml-4">
                        <button
                          onClick={() => editStock(p.id, 1)}
                          className="p-2 text-emerald-600 hover:bg-emerald-50 transition-colors"
                        >
                          <Plus className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => editStock(p.id, -1)}
                          className="p-2 text-red-500 hover:bg-red-50 transition-colors"
                        >
                          <Minus className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => deleteProduct(p.id)}
                          className="p-2 text-[#240046]/30 hover:text-red-500 transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Toast */}
      {toast && (
        <div className="fixed bottom-24 left-1/2 -translate-x-1/2 z-[70] px-6 py-3 bg-[#240046] text-white text-sm font-semibold shadow-2xl animate-fade-in">
          {toast}
        </div>
      )}
    </div>
  );
}
