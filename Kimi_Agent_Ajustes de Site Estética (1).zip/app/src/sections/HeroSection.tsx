import FluidReveal from './FluidReveal';
import { ArrowRight, MessageCircle } from 'lucide-react';

export default function HeroSection() {
  const scrollToPlanos = () => {
    document.querySelector('#planos')?.scrollIntoView({ behavior: 'smooth' });
  };

  const openWhatsApp = () => {
    const msg = encodeURIComponent(
      'Olá! Quero saber mais sobre o site profissional para minha clínica de estética'
    );
    window.open(`https://wa.me/5511953429077?text=${msg}`, '_blank');
  };

  return (
    <section id="hero" className="relative min-h-screen flex items-center overflow-hidden">
      {/* WebGL Fluid Background */}
      <FluidReveal imageUrl="/images/hero-clinic.jpg" />

      {/* Dark overlay for text readability */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#240046]/40 via-transparent to-[#240046]/60 z-[1]" />

      {/* Floating decorative elements */}
      <div className="absolute top-32 left-10 w-72 h-72 bg-purple-400/20 rounded-full blur-[100px] animate-blob z-[1]" />
      <div
        className="absolute bottom-20 right-10 w-96 h-96 bg-pink-400/10 rounded-full blur-[100px] animate-blob z-[1]"
        style={{ animationDelay: '-5s' }}
      />
      <div
        className="absolute top-1/2 left-1/3 w-64 h-64 bg-indigo-400/15 rounded-full blur-[80px] animate-blob z-[1]"
        style={{ animationDelay: '-10s' }}
      />

      {/* Content */}
      <div className="relative z-10 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-16">
        {/* Top metadata */}
        <div className="mb-8 animate-fade-in">
          <span className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 backdrop-blur-md border border-white/20 text-white/90 text-xs font-semibold uppercase tracking-widest">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            Sistemas para Estética / v2.0
          </span>
        </div>

        {/* Main headline */}
        <div className="max-w-4xl animate-slide-up" style={{ animationDelay: '0.1s' }}>
          <h1
            className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-light text-white leading-[1.05] tracking-tight uppercase"
            style={{ textShadow: '0 2px 30px rgba(36, 0, 70, 0.5)' }}
          >
            Transforme seu salão em uma{' '}
            <span className="text-[#D8B4FE] font-medium">máquina</span> de
            agendamentos <span className="italic font-display text-[#D8B4FE]">automáticos</span>
          </h1>
        </div>

        {/* Subtitle */}
        <div
          className="mt-8 max-w-2xl animate-slide-up"
          style={{ animationDelay: '0.2s' }}
        >
          <p className="text-lg sm:text-xl text-white/80 leading-relaxed">
            Site profissional com agendamento online direto pelo WhatsApp. 
            Perfeito para <strong className="text-white">esteticistas</strong>,{' '}
            <strong className="text-white">clínicas</strong> e{' '}
            <strong className="text-white">salões de beleza</strong>.
          </p>
        </div>

        {/* CTA Buttons */}
        <div
          className="mt-10 flex flex-col sm:flex-row gap-4 animate-slide-up"
          style={{ animationDelay: '0.3s' }}
        >
          <button
            onClick={scrollToPlanos}
            className="group px-8 py-4 bg-white text-[#240046] font-bold uppercase tracking-wider text-sm hover:shadow-brutalist-hover hover:-translate-x-px hover:-translate-y-px transition-all flex items-center justify-center gap-2"
          >
            Ver Planos e Preços
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>
          <button
            onClick={openWhatsApp}
            className="group px-8 py-4 bg-white/10 backdrop-blur-md border-2 border-white/30 text-white font-bold uppercase tracking-wider text-sm hover:bg-white/20 transition-all flex items-center justify-center gap-2"
          >
            <MessageCircle className="w-5 h-5" />
            Falar no WhatsApp
          </button>
        </div>

        {/* Stats row */}
        <div
          className="mt-16 grid grid-cols-3 gap-8 max-w-lg animate-slide-up"
          style={{ animationDelay: '0.4s' }}
        >
          <div>
            <div className="text-3xl sm:text-4xl font-bold text-white font-display italic">
              500+
            </div>
            <div className="text-xs sm:text-sm text-white/60 uppercase tracking-wider mt-1">
              Sites Criados
            </div>
          </div>
          <div>
            <div className="text-3xl sm:text-4xl font-bold text-white font-display italic">
              98%
            </div>
            <div className="text-xs sm:text-sm text-white/60 uppercase tracking-wider mt-1">
              Satisfação
            </div>
          </div>
          <div>
            <div className="text-3xl sm:text-4xl font-bold text-white font-display italic">
              24/7
            </div>
            <div className="text-xs sm:text-sm text-white/60 uppercase tracking-wider mt-1">
              Suporte
            </div>
          </div>
        </div>

        {/* Price anchor */}
        <div
          className="absolute bottom-16 right-4 sm:right-8 lg:right-16 hidden sm:block animate-slide-up"
          style={{ animationDelay: '0.5s' }}
        >
          <div className="text-right">
            <div className="text-xs text-white/60 uppercase tracking-widest mb-1">
              A partir de
            </div>
            <div className="text-5xl lg:text-6xl font-display italic text-white">
              R$ 600
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
