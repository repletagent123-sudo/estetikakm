import { useRef, useEffect, useCallback } from 'react';
import * as THREE from 'three';

const SIMULATION_VERTEX = `
  varying vec2 vUv;
  void main() {
    vUv = uv;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  }
`;

const SIMULATION_FRAGMENT = `
  uniform sampler2D uTexture;
  uniform vec4 iMouse;
  uniform vec2 uResolution;
  uniform float uBrushSize;
  uniform float uBrushStrength;
  uniform float uFluidDecay;
  uniform float uTrailLength;
  varying vec2 vUv;

  void main() {
    vec2 texel = 1.0 / uResolution;
    vec4 center = texture2D(uTexture, vUv);
    
    // Sample neighbors for diffusion
    vec4 left = texture2D(uTexture, vUv - vec2(texel.x, 0.0));
    vec4 right = texture2D(uTexture, vUv + vec2(texel.x, 0.0));
    vec4 up = texture2D(uTexture, vUv + vec2(0.0, texel.y));
    vec4 down = texture2D(uTexture, vUv - vec2(0.0, texel.y));
    
    // Diffuse
    vec4 diffused = (center + left + right + up + down) * 0.2;
    
    // Add velocity from mouse
    vec2 mousePos = iMouse.xy;
    vec2 mousePrev = iMouse.zw;
    vec2 velocity = mousePos - mousePrev;
    
    float dist = distance(vUv, mousePos);
    float brush = smoothstep(uBrushSize, 0.0, dist);
    
    diffused.rg += velocity * brush * uBrushStrength;
    diffused.b += length(velocity) * brush * uBrushStrength * 2.0;
    
    // Decay
    diffused *= uFluidDecay;
    diffused.b *= uTrailLength;
    
    gl_FragColor = diffused;
  }
`;

const DISPLAY_VERTEX = `
  varying vec2 vUv;
  void main() {
    vUv = uv;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  }
`;

const DISPLAY_FRAGMENT = `
  uniform sampler2D uSimulationTexture;
  uniform sampler2D uBaseTexture;
  uniform vec3 uFluidColor;
  uniform float uDistortionAmount;
  varying vec2 vUv;

  void main() {
    vec4 fluidData = texture2D(uSimulationTexture, vUv);
    
    vec2 distortion = fluidData.rg * uDistortionAmount;
    
    vec2 uv = vUv + distortion;
    uv = clamp(uv, 0.0, 1.0);
    
    vec4 baseImage = texture2D(uBaseTexture, uv);
    
    float fluidMask = smoothstep(0.05, 0.4, fluidData.b);
    
    vec4 fluidOverlay = vec4(uFluidColor, fluidMask * 0.7);
    
    vec3 finalColor = mix(baseImage.rgb, fluidOverlay.rgb, fluidMask * 0.5);
    
    // Add subtle glow where fluid is active
    float glow = smoothstep(0.1, 0.5, fluidData.b) * 0.15;
    finalColor += uFluidColor * glow;
    
    gl_FragColor = vec4(finalColor, 1.0);
  }
`;

interface FluidRevealProps {
  imageUrl: string;
  className?: string;
}

export default function FluidReveal({ imageUrl, className = '' }: FluidRevealProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.OrthographicCamera | null>(null);
  const rafRef = useRef<number>(0);
  const mouseRef = useRef({ x: 0.5, y: 0.5, px: 0.5, py: 0.5 });
  const simMaterialsRef = useRef<THREE.ShaderMaterial[]>([]);
  const displayMaterialRef = useRef<THREE.ShaderMaterial | null>(null);
  const rtRef = useRef<THREE.WebGLRenderTarget[]>([]);
  const frameCountRef = useRef(0);

  const init = useCallback(() => {
    const container = containerRef.current;
    if (!container) return;

    const width = container.offsetWidth || window.innerWidth;
    const height = container.offsetHeight || window.innerHeight;

    // Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: false, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.domElement.style.width = '100%';
    renderer.domElement.style.height = '100%';
    renderer.domElement.style.display = 'block';
    container.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Camera
    const camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
    cameraRef.current = camera;

    // Scenes
    const simScene = new THREE.Scene();
    const displayScene = new THREE.Scene();
    sceneRef.current = displayScene;

    // Render targets for ping-pong
    const simWidth = 512;
    const simHeight = 512;
    const rtOptions: THREE.RenderTargetOptions = {
      minFilter: THREE.LinearFilter,
      magFilter: THREE.LinearFilter,
      format: THREE.RGBAFormat,
      type: THREE.FloatType,
    };
    const rt0 = new THREE.WebGLRenderTarget(simWidth, simHeight, rtOptions);
    const rt1 = new THREE.WebGLRenderTarget(simWidth, simHeight, rtOptions);
    rtRef.current = [rt0, rt1];

    // Simulation material
    const simMaterial = new THREE.ShaderMaterial({
      vertexShader: SIMULATION_VERTEX,
      fragmentShader: SIMULATION_FRAGMENT,
      uniforms: {
        uTexture: { value: rt0.texture },
        iMouse: { value: new THREE.Vector4(0.5, 0.5, 0.5, 0.5) },
        uResolution: { value: new THREE.Vector2(simWidth, simHeight) },
        uBrushSize: { value: 0.08 },
        uBrushStrength: { value: 0.6 },
        uFluidDecay: { value: 0.98 },
        uTrailLength: { value: 0.95 },
      },
    });
    simMaterialsRef.current = [simMaterial];

    const simGeometry = new THREE.PlaneGeometry(2, 2);
    const simMesh = new THREE.Mesh(simGeometry, simMaterial);
    simScene.add(simMesh);

    // Load base texture
    const textureLoader = new THREE.TextureLoader();
    textureLoader.load(imageUrl, (texture) => {
      texture.minFilter = THREE.LinearFilter;
      texture.magFilter = THREE.LinearFilter;

      // Display material
      const displayMaterial = new THREE.ShaderMaterial({
        vertexShader: DISPLAY_VERTEX,
        fragmentShader: DISPLAY_FRAGMENT,
        uniforms: {
          uSimulationTexture: { value: rt0.texture },
          uBaseTexture: { value: texture },
          uFluidColor: { value: new THREE.Vector3(36 / 255, 0 / 255, 70 / 255) },
          uDistortionAmount: { value: 0.3 },
        },
      });
      displayMaterialRef.current = displayMaterial;

      const displayGeometry = new THREE.PlaneGeometry(2, 2);
      const displayMesh = new THREE.Mesh(displayGeometry, displayMaterial);
      displayScene.add(displayMesh);
    });

    // Animation loop
    let currentRT = 0;
    const animate = () => {
      rafRef.current = requestAnimationFrame(animate);
      frameCountRef.current++;

      // Update mouse uniforms with smooth interpolation
      const m = mouseRef.current;
      simMaterial.uniforms.iMouse.value.set(m.x, m.y, m.px, m.py);

      // Swap render targets
      const readRT = rtRef.current[currentRT];
      const writeRT = rtRef.current[1 - currentRT];

      // Simulation pass
      simMaterial.uniforms.uTexture.value = readRT.texture;
      renderer.setRenderTarget(writeRT);
      renderer.render(simScene, camera);

      // Display pass
      if (displayMaterialRef.current) {
        displayMaterialRef.current.uniforms.uSimulationTexture.value = writeRT.texture;
      }
      renderer.setRenderTarget(null);
      renderer.render(displayScene, camera);

      currentRT = 1 - currentRT;

      // Update previous mouse position
      m.px = m.x;
      m.py = m.y;
    };
    animate();
  }, [imageUrl]);

  useEffect(() => {
    init();

    const handleMouseMove = (e: MouseEvent) => {
      const container = containerRef.current;
      if (!container) return;
      const rect = container.getBoundingClientRect();
      mouseRef.current.x = (e.clientX - rect.left) / rect.width;
      mouseRef.current.y = 1.0 - (e.clientY - rect.top) / rect.height;
    };

    const handleResize = () => {
      const container = containerRef.current;
      const renderer = rendererRef.current;
      if (!container || !renderer) return;
      const w = container.offsetWidth;
      const h = container.offsetHeight;
      renderer.setSize(w, h);
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(rafRef.current);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('resize', handleResize);
      rendererRef.current?.dispose();
      rtRef.current.forEach(rt => rt.dispose());
      simMaterialsRef.current.forEach(m => m.dispose());
      displayMaterialRef.current?.dispose();
      if (containerRef.current && rendererRef.current?.domElement) {
        containerRef.current.removeChild(rendererRef.current.domElement);
      }
    };
  }, [init]);

  return (
    <div
      ref={containerRef}
      className={`absolute inset-0 ${className}`}
      style={{ zIndex: 0 }}
    />
  );
}
