import { useEffect, useRef } from 'react';
import { User, Building2, Store } from 'lucide-react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const audiences = [
  {
    icon: User,
    title: 'Esteticistas Autônomas',
    description:
      'Profissionais que atendem em casa ou estúdio próprio e querem profissionalizar o atendimento com um site moderno e agendamento automatizado.',
    image: '/images/esteticista-autonoma.jpg',
    tag: 'Autônomo',
  },
  {
    icon: Building2,
    title: 'Clínicas de Estética',
    description:
      'Clínicas que precisam de agendamento online e querem automatizar o atendimento para atender mais clientes e reduzir faltas.',
    image: '/images/clinica-estetica.jpg',
    tag: 'Clínica',
  },
  {
    icon: Store,
    title: 'Pequenos Comércios',
    description:
      'Negócios de beleza e estética que querem vender mais, conquistar novos clientes e se destacar da concorrência online.',
    image: '/images/pequeno-comercio.jpg',
    tag: 'Comércio',
  },
];

export default function ParaQuemSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const cardsRef = useRef<HTMLDivElement[]>([]);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const cards = cardsRef.current;
    const triggers: ScrollTrigger[] = [];

    cards.forEach((card, i) => {
      if (!card) return;
      const tl = gsap.timeline({
        scrollTrigger: {
          trigger: card,
          start: 'top 85%',
          end: 'top 50%',
          toggleActions: 'play none none reverse',
        },
      });

      tl.fromTo(
        card,
        { opacity: 0, y: 60, scale: 0.95 },
        { opacity: 1, y: 0, scale: 1, duration: 0.8, ease: 'power3.out', delay: i * 0.15 }
      );

      if (tl.scrollTrigger) triggers.push(tl.scrollTrigger);
    });

    return () => {
      triggers.forEach(t => t.kill());
    };
  }, []);

  return (
    <section ref={sectionRef} className="relative py-24 sm:py-32 bg-white overflow-hidden">
      {/* Subtle background pattern */}
      <div className="absolute inset-0 opacity-[0.02]" style={{
        backgroundImage: `radial-gradient(circle at 1px 1px, #240046 1px, transparent 0)`,
        backgroundSize: '40px 40px'
      }} />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <span className="inline-block px-4 py-1.5 bg-[#240046]/5 text-[#240046] text-xs font-bold uppercase tracking-widest mb-4">
            Público-Alvo
          </span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-light text-[#240046] tracking-tight uppercase">
            Solução Perfeita Para <span className="font-medium">Você</span>
          </h2>
          <p className="mt-4 text-lg text-[#240046]/60 max-w-2xl mx-auto">
            Atendemos diferentes perfis de profissionais da beleza e estética
          </p>
        </div>

        {/* Cards Grid */}
        <div className="grid md:grid-cols-3 gap-6 lg:gap-8">
          {audiences.map((item, i) => (
            <div
              key={item.title}
              ref={el => { if (el) cardsRef.current[i] = el; }}
              className="group relative bg-white border border-[#240046]/10 overflow-hidden hover:shadow-brutalist hover:-translate-x-px hover:-translate-y-px transition-all duration-300"
            >
              {/* Image */}
              <div className="relative h-64 overflow-hidden">
                <img
                  src={item.image}
                  alt={item.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#240046]/80 via-[#240046]/20 to-transparent" />
                
                {/* Tag */}
                <div className="absolute top-4 left-4">
                  <span className="px-3 py-1 bg-white/90 backdrop-blur-sm text-[#240046] text-xs font-bold uppercase tracking-wider">
                    {item.tag}
                  </span>
                </div>

                {/* Icon */}
                <div className="absolute bottom-4 right-4 w-12 h-12 bg-white/20 backdrop-blur-md border border-white/30 flex items-center justify-center">
                  <item.icon className="w-6 h-6 text-white" />
                </div>
              </div>

              {/* Content */}
              <div className="p-6">
                <h3 className="text-xl font-semibold text-[#240046] mb-3">
                  {item.title}
                </h3>
                <p className="text-sm text-[#240046]/60 leading-relaxed">
                  {item.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
