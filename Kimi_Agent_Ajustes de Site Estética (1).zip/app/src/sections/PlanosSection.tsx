import { useEffect, useRef } from 'react';
import { Check, Minus, Zap, Crown, Star } from 'lucide-react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const features = [
  { name: 'Design moderno e responsivo', c: true, g: true, combo: true },
  { name: 'Agendamento via WhatsApp', c: true, g: true, combo: true },
  { name: 'Otimizado para Google (SEO)', c: true, g: true, combo: true },
  { name: 'Catálogo de serviços com fotos', c: true, g: true, combo: true },
  { name: 'Botão flutuante WhatsApp', c: true, g: true, combo: true },
  { name: 'Hospedagem inclusa', c: false, g: true, combo: true },
  { name: 'Domínio personalizado', c: false, g: true, combo: true },
  { name: 'Atualizações ilimitadas', c: false, g: true, combo: true },
  { name: 'Suporte técnico prioritário', c: false, g: true, combo: true },
  { name: 'Painel de agendamentos', c: false, g: true, combo: true },
  { name: 'Controle de estoque', c: false, g: true, combo: true },
  { name: 'Relatórios mensais', c: false, g: true, combo: true },
];

const plans = [
  {
    key: 'c',
    name: 'Criação do Site',
    subtitle: 'Pagamento Único',
    price: 'R$ 600',
    period: '',
    description: 'Seu site profissional pronto em até 7 dias',
    cta: 'Quero Meu Site',
    whatsappMsg: 'Olá! Quero contratar a criação do site profissional por R$ 600',
    icon: Star,
    featured: false,
    gradient: 'bg-[#240046]',
  },
  {
    key: 'g',
    name: 'Gestão Mensal',
    subtitle: 'Recomendado',
    price: 'R$ 80',
    period: '/mês',
    description: 'Manutenção + suporte + atualizações',
    cta: 'Contratar Gestão',
    whatsappMsg: 'Olá! Quero contratar a gestão mensal do site por R$ 80/mês',
    icon: Zap,
    featured: true,
    gradient: 'bg-gradient-to-br from-[#240046] via-[#5B21B6] to-[#7C3AED]',
  },
  {
    key: 'combo',
    name: 'Combo Completo',
    subtitle: 'Melhor Custo-Benefício',
    price: 'R$ 600',
    period: ' + R$ 80/mês',
    description: 'Site + Gestão mensal completa',
    cta: 'Quero o Combo',
    whatsappMsg: 'Olá! Quero contratar o Combo Completo (Site + Gestão Mensal)',
    icon: Crown,
    featured: false,
    gradient: 'bg-gradient-to-br from-[#31154F] to-[#240046]',
  },
];

export default function PlanosSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const tableRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const section = sectionRef.current;
    const table = tableRef.current;
    if (!section || !table) return;

    const triggers: ScrollTrigger[] = [];

    // Animate header
    const headerTl = gsap.timeline({
      scrollTrigger: {
        trigger: section,
        start: 'top 80%',
        toggleActions: 'play none none reverse',
      },
    });
    headerTl.fromTo(
      section.querySelector('.planos-header'),
      { opacity: 0, y: 40 },
      { opacity: 1, y: 0, duration: 0.8, ease: 'power3.out' }
    );
    if (headerTl.scrollTrigger) triggers.push(headerTl.scrollTrigger);

    // Animate pricing cards
    const cards = table.querySelectorAll('.plan-card');
    cards.forEach((card, i) => {
      const tl = gsap.timeline({
        scrollTrigger: {
          trigger: card,
          start: 'top 85%',
          toggleActions: 'play none none reverse',
        },
      });
      tl.fromTo(
        card,
        { opacity: 0, y: 50 },
        { opacity: 1, y: 0, duration: 0.7, ease: 'power3.out', delay: i * 0.1 }
      );
      if (tl.scrollTrigger) triggers.push(tl.scrollTrigger);
    });

    return () => {
      triggers.forEach(t => t.kill());
    };
  }, []);

  const openWhatsApp = (msg: string) => {
    const encoded = encodeURIComponent(msg);
    window.open(`https://wa.me/5511953429077?text=${encoded}`, '_blank');
  };

  const getFeatureIcon = (value: boolean) => {
    if (value) {
      return (
        <div className="w-6 h-6 rounded-full bg-emerald-100 flex items-center justify-center flex-shrink-0">
          <Check className="w-4 h-4 text-emerald-600" />
        </div>
      );
    }
    return (
      <div className="w-6 h-6 rounded-full bg-gray-100 flex items-center justify-center flex-shrink-0">
        <Minus className="w-4 h-4 text-gray-400" />
      </div>
    );
  };

  return (
    <section
      id="planos"
      ref={sectionRef}
      className="relative py-24 sm:py-32 bg-[#F5F5F5] overflow-hidden"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="planos-header text-center mb-16">
          <span className="inline-block px-4 py-1.5 bg-[#240046] text-white text-xs font-bold uppercase tracking-widest mb-4">
            Investimento
          </span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-light text-[#240046] tracking-tight uppercase">
            Escolha o Plano Ideal Para{' '}
            <span className="font-medium">Seu Negócio</span>
          </h2>
          <p className="mt-4 text-lg text-[#240046]/60 max-w-2xl mx-auto">
            Site profissional + agendamento automático + gestão inteligente
          </p>
        </div>

        {/* Pricing Cards */}
        <div ref={tableRef} className="grid md:grid-cols-3 gap-6 lg:gap-8">
          {plans.map((plan) => (
            <div
              key={plan.key}
              className={`plan-card relative bg-white border-2 overflow-hidden transition-all duration-300 hover:shadow-brutalist hover:-translate-x-px hover:-translate-y-px ${
                plan.featured
                  ? 'border-[#240046] shadow-brutalist scale-[1.02] md:scale-[1.03]'
                  : 'border-[#240046]/10'
              }`}
            >
              {/* Featured Badge */}
              {plan.featured && (
                <div className="absolute top-0 right-0 bg-[#240046] text-white text-xs font-bold uppercase tracking-wider px-4 py-2 z-10">
                  Mais Popular
                </div>
              )}

              {/* Header */}
              <div className={`${plan.gradient} p-8 text-white`}>
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 bg-white/20 backdrop-blur-sm border border-white/30 flex items-center justify-center">
                    <plan.icon className="w-5 h-5 text-white" />
                  </div>
                  <span className="text-xs font-bold uppercase tracking-widest text-white/70">
                    {plan.subtitle}
                  </span>
                </div>
                <h3 className="text-2xl font-semibold mb-1">{plan.name}</h3>
                <div className="flex items-baseline gap-2 mt-4">
                  <span className="text-5xl font-display italic text-white">
                    {plan.price}
                  </span>
                  {plan.period && (
                    <span className="text-white/70 text-lg">{plan.period}</span>
                  )}
                </div>
                <p className="text-white/70 text-sm mt-2">{plan.description}</p>
              </div>

              {/* Features */}
              <div className="p-6">
                <ul className="space-y-3">
                  {features.map((f) => (
                    <li
                      key={f.name}
                      className="flex items-center gap-3 text-sm"
                    >
                      {getFeatureIcon(
                        plan.key === 'c'
                          ? f.c
                          : plan.key === 'g'
                          ? f.g
                          : f.combo
                      )}
                      <span className="text-[#240046]/80">{f.name}</span>
                    </li>
                  ))}
                </ul>

                {/* CTA Button */}
                <button
                  onClick={() => openWhatsApp(plan.whatsappMsg)}
                  className={`w-full mt-8 py-4 font-bold uppercase tracking-wider text-sm transition-all hover:shadow-brutalist-hover hover:-translate-x-px hover:-translate-y-px ${
                    plan.featured
                      ? 'bg-[#240046] text-white'
                      : 'bg-[#240046]/5 text-[#240046] border-2 border-[#240046]/20 hover:bg-[#240046] hover:text-white'
                  }`}
                >
                  {plan.cta}
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom trust text */}
        <div className="mt-12 text-center">
          <p className="text-sm text-[#240046]/50">
            Sem fidelidade — cancele quando quiser. Pagamento via PIX ou transferência bancária.
          </p>
        </div>
      </div>
    </section>
  );
}
